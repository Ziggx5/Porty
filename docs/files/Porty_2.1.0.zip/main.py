from modules.ui import start_ui

def main():
    start_ui()

if __name__ == "__main__":
    main()